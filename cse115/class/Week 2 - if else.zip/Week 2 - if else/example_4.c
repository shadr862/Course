#include <stdio.h>

int main(){
    int n;

    printf("Enter a number between (1-3):");
    scanf("%d", &n);

    switch(n){
        case 1:
            printf("Pressed 1!\n");
            break;
        case 2:
            printf("Pressed 2!\n");
            break;
        case 3:
            printf("Pressed 3!\n");
            break;
        default:
            printf("You did not press between (1-3)\n");
    }

    return 0;
}
