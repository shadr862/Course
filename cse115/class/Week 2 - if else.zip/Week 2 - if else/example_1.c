#include <stdio.h>

int main(){
    if(1){
        printf("The statement is true!!\n");
    }

    return 0;
}
