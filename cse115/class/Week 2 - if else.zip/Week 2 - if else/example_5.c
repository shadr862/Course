#include <stdio.h>

int main(){
    char c;

    printf("Enter a Grade letter:");
    scanf("%c", &c);

    switch(c){
        case 'A':
        case 'a':
            printf("You got A!\n");
            break;
        case 'B':
        case 'b':
            printf("You got B!\n");
            break;
        case 'C':
        case 'c':
            printf("You got C!\n");
            break;
        default:
            printf("Invalid Grade!\n");
    }

    return 0;
}
