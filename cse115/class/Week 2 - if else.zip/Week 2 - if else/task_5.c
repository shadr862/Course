#include <stdio.h>

int main(){
    char op;
    int a, b;

    printf("Enter the operator: ");
    scanf("%c", &op);
    printf("Enter a: ");
    scanf("%d", &a);
    printf("Enter b: ");
    scanf("%d", &b);

    switch(op){
        case '+':
            printf("Result: %d\n", a+b);
            break;
        case '-':
            printf("Result: %d\n", a-b);
            break;
        case '*':
            printf("Result: %d\n", a*b);
            break;
        case '/':
            printf("Result: %d\n", a/b);
            break;
        default:
            printf("Invalid Input!\n");
    }

    return 0;
}
