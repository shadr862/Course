#include <stdio.h>

int main(){
    char c;

    printf("Enter a character:");
    scanf("%c", &c);

    if(c=='a' || c=='A')
        printf("You pressed A!!");
    else if(c=='b' || c=='B')
        printf("You pressed B!");
    else if(c=='c' || c=='C')
        printf("You pressed C!");
    else
        printf("You pressed different key!");

    return 0;
}

