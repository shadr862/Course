#include <stdio.h>

int main(){
    int a, b, c;

    printf("Enter a: ");
    scanf("%d", &a);
    printf("Enter b: ");
    scanf("%d", &b);
    printf("Enter c: ");
    scanf("%d", &c);

    if(a>b){
        if(a>c)
            printf("Max: %d", a);
        else
            printf("Max: %d", c);
    }
    else{
        if(b>c)
            printf("Max: %d", b);
        else
            printf("Max: %d", c);
    }

    return 0;
}
