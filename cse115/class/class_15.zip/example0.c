#include <stdio.h>

void main (){
 //   int a = 5;
const int a = 5;
printf ("\nThe value of a is = %d ", a);
a = 6;
printf ("\nThe value of a is = %d", a);
}
