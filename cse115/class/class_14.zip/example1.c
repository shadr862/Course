#include <stdio.h>

void main () {
int x;
int *y;
y=&x;
x=10;
//int x,*y = &x;
//x = 10;
printf ("\nThe value of x is %d and address is %p\n", x, &x); //output a pointer
printf ("\nThe value of x is %d and address is %x\n", x, &x);
printf ("\nThe value of x is %d and address is %x\n", *y, y);
}
