#include <stdio.h>

int main () {

char abc;
printf ("Enter a or b or c or d or e: ");
scanf ("%c",&abc);

switch (abc){
case 'a':
    printf("\nHave a good morning!");
    break;
case 'b':
    printf("\nHave a nice evening!");
    break;
case 'c':
    printf("\nHave a nice day!");
    break;
default:
    printf ("\nNo wish for you!");
}
return 0;
}
