#include <stdio.h>

void main(){
char ch;
scanf ("%c", &ch);
printf("\n The character is: %c", ch);
printf("\n The ASCII value of the character: %d", ch);
}
