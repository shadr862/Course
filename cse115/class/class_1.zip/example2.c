//Rules of Evaluating Expressions

#include <stdio.h>
void main() {
int z = 8, a = 3, b = 9, w=2, y = -5;
int result;
result = z - (a+b/2) + w * -y;
printf("\nThe result is %d", result);
}
