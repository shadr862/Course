#include <stdio.h>

int main(){
    int in, sum = 0;

    printf("how many number you wants to enter: ");
    scanf("%d", &in);

    int i = 1;
    while(i<=in){
        int num;
        printf("%d. Enter number: ", i);
        scanf("%d", &num);

        sum = sum + num;
        i++;
    }

    printf("Sum: %d\n", sum);

    return 0;
}
