#include <stdio.h>

int main(){
    int a, b;
    printf("Enter two integers: ");
    scanf("%d %d", &a, &b);

    int min = (a>b) ? b:a;

    int i, gcd;
    for(i=1; i<=min; i++){
        if(a%i==0 && b%i==0)
            gcd = i;
    }

    printf("GCD: %d", gcd);

    return 0;
}
