#include <stdio.h>

int main(){
    int n;
    printf("Enter n: ");
    scanf("%d", &n);

    printf("The first %d Fibonacci numbers are: ", n);

    int i, fib1=0, fib2=1, fib;
    for(i=0; i<n; i++){
        if(i<=1){
            fib = i;
        }
        else{
            fib = fib1 + fib2;
            fib1 = fib2;
            fib2 = fib;
        }

        printf("%d ", fib);
    }

    return 0;
}
