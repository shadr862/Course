#include <stdio.h>

int main(){
    int i;

    for(i=0; i<5; i++){
        printf("Repeating %d times!\n",i);
    }

    return 0;
}
