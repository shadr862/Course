#include <stdio.h>

int main(){
    int i, j, k, n;
    printf("Enter n: ");
    scanf("%d", &n);

    for(i=n; i>0; i--){
        for(j=0, k=n; j<i; j++, k--){
            printf("%d ", k);
        }
        printf("\n");
    }

    return 0;
}
