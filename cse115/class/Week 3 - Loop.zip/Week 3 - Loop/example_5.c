#include <stdio.h>

int main(){
    int i;

    for(i=10; i>=0; i--){
        if(i==6 || i==3)
            continue;
        else
            printf("%d ",i);
    }

    return 0;
}
