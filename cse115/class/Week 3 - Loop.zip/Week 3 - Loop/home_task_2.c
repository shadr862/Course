#include <stdio.h>

int main(){
    int num;
    printf("Enter a number: ");
    scanf("%d", &num);

    int i, sum=0;
    while(num != 0){
        sum = sum + num%10;
        num = num/10;
    }

    printf("Sum of the digit: %d\n", sum);

    return 0;
}
