#include <stdio.h>

int main(){
    int num;

    do{
        printf("Enter a number:");
        scanf("%d", &num);
    }while(num%2 == 0);

    return 0;
}
