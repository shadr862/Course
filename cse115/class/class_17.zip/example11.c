#include <stdio.h>
#include <string.h>
int main() {

  char ch1= 'f';
  char ch2= 'o';
 int dif = ch1 - ch2;
 printf("\n%d", dif);

return 0;
}
