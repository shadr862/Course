#include <stdio.h>
#include <string.h>
#define size 15
int main () {
char f1 [size]="Albert" , f2 [size] = "Einstein";
puts (f1);
strcat (f1, f2);
puts (f1);
return 0;
}
