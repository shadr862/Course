//typedef
#include<stdio.h>

int main()
{
typedef int nilshagor;
nilshagor num1 = 100,num2 = 200;
nilshagor answer;
//int answer;
answer = num1 + num2;
printf("Answer : %d",answer);
return(0);
}
