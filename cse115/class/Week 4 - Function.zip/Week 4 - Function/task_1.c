#include <stdio.h>

float getBase();
float getHeight();
float getAreaTriangle(float base, float height);

int main(){
    float base, height;

    printf("Enter base: ");
    base = getBase();
    printf("Enter height: ");
    height = getHeight();

    printf("The base is: %0.1f cm and height is: %0.1f cm\n", base, height);
    printf("The area of the triangle is : %0.1f cm^2\n", getAreaTriangle(base, height));

    return 0;
}

float getBase(){
    float b;
    scanf("%f", &b);

    return b;
}

float getHeight(){
    float h;
    scanf("%f", &h);

    return h;
}

float getAreaTriangle(float base, float height){
    return 0.5*base*height;
}
