#include <stdio.h>

int getNum();
int getSquare(int n);
int getCube(int n);

int main(){
    printf("Enter number: ");
    int num = getNum();

    printf("The square of the number is: %d\n", getSquare(num));
    printf("The square of the number is: %d\n", getCube(num));

    return 0;
}

int getNum(){
    int n;
    scanf("%d", &n);
    return n;
}

int getSquare(int n){
    return n*n;
}

int getCube(int n){
    return n*n*n;
}
