#include <stdio.h>

int factorial(int n);
int combination(int n, int r);

int main(){
    int n, r;
    printf("Enter values of n and r: ");
    scanf("%d %d", &n, &r);

    printf("Combination: %d\n", combination(n, r));

    return 0;
}

int factorial(int n){
    int i=1, fac=1;

    while(i<=n){
        fac = fac*i;
        i++;
    }

    return fac;
}

int combination(int n, int r){
    return factorial(n) / (factorial(r) * factorial(n-r));
}
