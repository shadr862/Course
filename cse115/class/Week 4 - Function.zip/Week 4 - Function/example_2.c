#include <stdio.h>

void average(int first, int second);

int main(){
    int a=7, b=8;
    average(a,b);

    return 0;
}

void average(int first, int second){
    printf("%f", (first+second)/2.0);
}
