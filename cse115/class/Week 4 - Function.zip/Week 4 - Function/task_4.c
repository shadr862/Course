#include <stdio.h>

int checkPrimeNumber(int n);

int main(){
    int start, end;
    printf("Enter upper bound: ");
    scanf("%d", &start);
    printf("Enter lower bound: ");
    scanf("%d", &end);

    printf("Prime number between %d and %d are:\n", start, end);
    int i;
    for(i=start; i<=end; i++){
        if(checkPrimeNumber(i))
            printf("%d, ", i);
    }

    return 0;
}

int checkPrimeNumber(int n){
    int flag = 1;

    if(n==1)
        flag = 0;

    int i;
    for(i=2; i<=n/2; i++){
        if(n%i==0){
            flag = 0;
            break;
        }
    }

    return flag;
}
