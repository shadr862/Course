#include <stdio.h>

float average(int first, int second);

int main(){
    int a=7, b=8;
    printf("%f", average(a,b));

    return 0;
}

float average(int first, int second){
    return (first+second)/2.0;
}
