#include <stdio.h>
int main(){
int x;
for (x=0; x<100 ; x++){
     printf("%d I will be printed\n",x);
     //continue;
    if (x==10){
        break;
        printf("I will never be printed");
    }
   continue;
}
printf("\nWhatever it is, I will always be printed\n");
return 0;
}
