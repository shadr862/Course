
#include <stdio.h>
struct student {
char name [10];
int ID;
char dept [10];
float CGPA;
};
int main () {
struct student n;
printf ("\nThe size of the structure is: %d %d %d %d %d\n", sizeof(n.name), sizeof (nilshagor.ID), sizeof (n.dept), sizeof (n.CGPA), sizeof (n));
return 0;
}
