// function without argument
#include <stdio.h>
// function prototype
double res_area ();
int main (){
double result;
result= res_area();
printf ("Area of the circle is %.2f", result);
return (0);
}
//function definition
double res_area (){
double r;
double area;
printf ("\nEnter the radius: ");
scanf ("%lf",&r);
area = 3.1416 * r * r;
return area;
}
