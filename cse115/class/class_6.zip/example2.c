
#include <stdio.h>
void res_area ();
int main (){
double r;
double area;
printf ("\nEnter the radius: ");
scanf ("%lf",&r);
area = 3.1416 * r * r;
printf ("Area of the circle is %.2f", area);
return (0);
}

