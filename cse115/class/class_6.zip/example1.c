// function without argument
#include <stdio.h>
// function prototype
void draw_circle();

void main() {

draw_circle ();
//draw_circle ();
//draw_circle ();
//return 0;
}
//function definition
void draw_circle(){
printf ("    *   \n");
printf (" *    * \n");
printf ("   **   \n");
printf ("\n");
}
