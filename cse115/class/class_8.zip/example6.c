#include <stdio.h>

void  main () {

while (4<1)
{
    printf("\nwhile!");
}
   printf("\nwhile doesn't work!");
do
{
    printf("\ndo works!");

}while (4<1);

}
