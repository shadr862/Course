#include <stdio.h>

void  main () {
while (1)
{
    printf ("Hello world");
}

}
