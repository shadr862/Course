#include <stdio.h>

int main () {
int answer;

printf ("What is 5 + 10? ");
scanf ("%d",&answer);

if (answer == 5 +10){
    printf ("right answer!");}

else{
       printf ("Go back to your mom!");
}

return 0;
}
