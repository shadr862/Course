#include <stdio.h>

void main (){
int NSU_007;
int CSE;
int result;
int remainder;
NSU_007= 3;
CSE = 16;
result =  CSE / NSU_007 ;
printf("\nThe division is: %d", result);
remainder =  CSE % NSU_007 ;
printf("\nThe remainder is: %d", remainder);
}
