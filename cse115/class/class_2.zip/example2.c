#include <stdio.h>

void main (){
char ch;
printf("Enter a character in Capital:");
scanf("%c",&ch);
printf("\n you have entered: %c", ch);
printf("\n And the value is: %d", ch);
printf("\nConverted to: %c", ch-32);
}
