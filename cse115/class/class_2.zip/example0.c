#include <stdio.h>

void main(){

printf("Welcome to CSE115");
int x;
int y;
int z;
//x= 1;
//y=99;
printf("\nEnter the value of x:");
scanf ("%d", &x);
printf("\nEnter the value of y:");
scanf ("%d", &y);
z = x + y;
printf ("\nThe value of z is: %d", z);

}
