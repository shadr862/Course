#include <stdio.h>

void main (){
int rub_e;
int hap1;
float result;
int remainder;
rub_e= 16;
hap1 = 3;
result =  hap1/rub_e ;
printf("\nThe division is: %.2f", result);
//printf("\nThe division is: %.2f", (float)happy/ rub_el);
remainder =  hap1 % rub_e ;
printf("\nThe remainder is: %d", remainder);
}
